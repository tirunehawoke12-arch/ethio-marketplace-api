# 🇪🇹 ኢትዮ ዲጂታል ማርኬት — Next.js + Tailwind CSS

አንድ ሰርቨር (Node): **Express API** (`server/`) + **Next.js 14** ገጾች (`src/`) + **Tailwind CSS**።
ውሂብ በ Postgres (Neon)፤ መግቢያ በይለፍ ቃል + በተመዘገበው ስልክ ብቻ የሚላክ Telegram OTP።

## አወቃቀር
```
server.js            ← መነሻ (Express + Next አንድ ላይ)
server/app.js        ← OTP/Telegram፣ ማከማቻ፣ አድሚን፣ ክፍለ-ጊዜ
server/auth.js       ← ምዝገባ/መግቢያ (PBKDF2 — ከድሮው ጋር ተኳሃኝ)
server/market.js     ← ሱቅ፣ ዕቃ፣ ትዕዛዝ (escrow)፣ ግምገማ
server/people.js     ← ሠራተኛ፣ አሰሪ፣ ሥራ፣ ማመልከቻ
src/app/**           ← ገጾች (App Router)
src/components/**    ← ክፍሎች     src/lib/** ← API፣ ቅጽ፣ ቋሚዎች
public/              ← og.png፣ Google ማረጋገጫ ፋይል
```

## በኮምፒዩተር ላይ መሞከር
```bash
npm install
cp .env.example .env     # ዋጋዎቹን ይሙሉ
npm run build
npm start                # http://localhost:3000
```

## 🚀 Render ላይ መጫን (ደረጃ በደረጃ)
1. **GitHub፦** በ repo ውስጥ ያሉትን የድሮ ፋይሎች በሙሉ ያጥፉ (`app.js`፣ `index.html`፣ `market.js`፣ `market-ui.js`፣ `people.js`፣ `package*.json`፣ `og.png`…)፤ ከዚያ ይህን ፕሮጀክት (ሁሉንም ፋይሎች እና አቃፊዎች) ይጫኑ። **አቃፊዎችን (`src`፣ `server`፣ `public`) መጎተት ኮምፒዩተር ላይ ብቻ ይሠራል።**
2. **Render → Settings፦**
   - Build Command፦ `npm install && npm run build`
   - Start Command፦ `npm start`
   - Health Check Path፦ `/api/health`
3. **Environment፦** `.env.example` ውስጥ ያሉትን ሁሉ ያስገቡ። ዋና ዋናዎቹ፦ `DATABASE_URL`፣ `ADMIN_PASSWORD`፣ `ADMIN_EMAIL`፣ `TOKEN_SECRET`፣ `TELEGRAM_*`፣ `SITE_URL`፣ `NEXT_PUBLIC_SITE_URL`፣ `NODE_OPTIONS=--max-old-space-size=460`።
4. **Deploy** ይጫኑ፤ Logs ውስጥ `Postgres storage ready` እና `listening on port` ይፈልጉ።
5. ያረጋግጡ፦ `/api/health` → `"ok":true`፤ `/robots.txt`፤ `/sitemap.xml`።
6. **አድሚን፦** `/login` → «አድሚን ነዎት?» → ኢሜይል (ADMIN_EMAIL) + የይለፍ ቃል (ADMIN_PASSWORD)። ከዚያ `/admin` → ገበያ → ⚙️ ቅንብር ውስጥ **የክፍያ አካውንቶችን** (ዘዴ|ቁጥር|ባለቤት) እና ኮሚሽን ያስገቡ።

## 🆕 ስሪት 4 — የራስ ገጽ እና የክፍያ ደረሰኝ
- **🌐 የራስ ገጽ (`/me/sites/new`)፦** ማንኛውም የተመዘገበ ሰው (ሠራተኛ፣ አሰሪ፣ ሱቅ፣ ሆቴል፣ ክሊኒክ… ወይም ባዶ) ከአብነት ይጀምራል፤ ክፍሎችን እና ጥያቄዎችን እንደ Google Form ራሱ ይቀርጻል (10 የመልስ ዓይነቶች፦ ጽሑፍ፣ ቁጥር፣ ስልክ፣ ሊንክ፣ ቀን፣ ምርጫ፣ ብዙ ምርጫ፣ አዎ/አይደለም፣ ፎቶ)፣ ራሱ ይሞላል → ገጹ `/site/<id>` ላይ እንደ ራሱ ድረ-ገጽ ይታያል። ሁሉም ክፍል 👁 እና «ተጨማሪ ይመልከቱ» አለው። ዝርዝር፦ `/sites`።
- **🔒 «ለአድሚን ብቻ»፦** በመስክ ላይ ምልክት ሲደረግ (የክፍያ አካውንት፣ መታወቂያ…) ከህዝብ API ይወገዳል፤ አድሚን በ `/admin → 🌐 ገጾች` ያየዋል።
- **📝 የጎብኝ ቅጽ፦** ባለቤቱ ቀጠሮ/ክፍል ማስያዣ/ማመልከቻ ቅጽ ያዘጋጃል፤ የገቡ ተጠቃሚዎች ይሞላሉ → መልሶች በ «📬 መልሶች» ይታያሉ + Telegram ማሳወቂያ።
- **🧾 ደረሰኝ፦** አድሚን ክፍያ ሲያረጋግጥ (ለገዥ)፣ ለሻጭ ሲከፍል (ለሻጭ)፣ ተመላሽ ሲያደርግ (ለገዥ) bot «🧾 ደረሰኝ አውርድ» ቁልፍ ያለው መልዕክት ይልካል። ሊንኩ `/r/<የተፈረመ ቶከን>` (90 ቀን፣ ሊቀየር አይችልም)፤ `?dl=1` ፋይል ሆኖ ይወርዳል፣ «አትም / PDF» ቁልፍ አለው። በድረ-ገጹ ደግሞ በ ትዕዛዝ ገጽ እና በሻጭ ትዕዛዝ ዝርዝር ውስጥ ይገኛል። **ማስታወሻ፦** የ Telegram ቁልፍ እንዲሠራ `PUBLIC_BASE_URL` በ `https://` መጀመር አለበት።

## 🤖 ስሪት 5 — ሙሉ ድረ-ገጹ በ Telegram bot ውስጥም
ቦቱ (`server/bot.js`) ለተገናኘው አካውንት በተፈረመ ቶከን ወደ ራሱ API (127.0.0.1) ይጠራል — ስለዚህ ህጎች፣ escrow፣ ማረጋገጫዎች እና ማሳወቂያዎች ከድረ-ገጹ ጋር አንድ ናቸው።
- **መግቢያ/ምዝገባ፦** `/start` → «📱 ስልኬን አጋራ» (Telegram ስልኩን ያረጋግጣል) → ነባር አካውንት ካለ የይለፍ ቃል፤ ከሌለ ኢሜይል + ስም + የይለፍ ቃል (የይለፍ ቃል መልዕክቶች ወዲያው ይሰረዛሉ)። በቦቱ የተከፈተ አካውንት በድረ-ገጹም ይሠራል።
- **ማውጫ፦** 🛍 ገበያ · 🏪 ሱቆች · 💼 ሥራ · 🌐 ገጾች · 🛒 ጋሪ · 📦 ትዕዛዞቼ · 👤 ገጾቼ · 🔎 ፈልግ · ❓ እገዛ (+ 🛡 አድሚን ለ `ADMIN_TELEGRAM_CHAT_ID`)።
- **ገዥ፦** መፈለግ፣ ጋሪ፣ ትዕዛዝ (በአካል/ማድረስ)፣ ክፍያ ማስገባት፣ መሰረዝ፣ «ደርሶኛል»፣ ክርክር፣ ግምገማ፣ ደረሰኝ ማውረድ።
- **ሻጭ፦** ሱቅ መክፈት/ማስተካከል (ፎቶ ጨምሮ)፣ ዕቃ መጨመር/ማስተካከል/መደበቅ/መሰረዝ፣ ትዕዛዝ መቀበል/መላክ — ማሳወቂያው ላይ ✅/✕ ቁልፍ አለ።
- **ሥራ፦** ክፍት ሥራ/ሠራተኛ ማየት፣ ማመልከት፣ ቅጥር መጠየቅ፣ ሠራተኛ/አሰሪ ገጽ፣ ሥራ ማስታወቅ፣ አመልካቾችን ዝርዝር/ቅጥር/ውድቅ።
- **የራስ ገጽ፦** አብነት መርጦ ጥያቄ በጥያቄ መሙላት፣ የሌሎችን ገጽ ክፍል በክፍል 👁 ማየት፣ የጎብኝ ቅጽ መሙላት፣ መልሶችን ማየት፣ መደበቅ/መሰረዝ። (ጥያቄዎችን መጨመር/መቀየር በድረ-ገጽ አርታዒ ሊንክ ነው።)
- **አድሚን፦** ክፍያ ✅/❌፣ ለሻጭ መክፈል (ማጣቀሻ)፣ ተመላሽ፣ ክርክር፣ ሱቅ ማጽደቅ/ውድቅ፣ ገጽ/ሠራተኛ/አሰሪ/ሥራ ማገድ — ማሳወቂያዎች ላይ ቁልፎች አሉ።
- **⚙️ አካውንት (ስሪት 6)፦** `/account` ወይም «ገጾቼ → ⚙️ አካውንቴ»፦ መገለጫ፣ ስም/ኢሜይል/ስልክ መቀየር (ኢሜይል እና ስልክ መቀየር የአሁኑን የይለፍ ቃል ይጠይቃል፤ ስልክ በ Telegram ይረጋገጣል)፣ የይለፍ ቃል መቀየር፣ 🔔 ማሳወቂያ ማጥፋት (ቁልፍ የሌላቸው መልዕክቶች ብቻ)፣ 🚪 ውጣ (`/logout` — የ Telegram ግንኙነት ይቋረጣል፤ ጋሪ ይጸዳል)፣ 🗑 አካውንት ሰርዝ (የይለፍ ቃል + «ሰርዝ» ይጠይቃል፤ ንቁ ትዕዛዝ ካለ አይፈቀድም፤ ሱቅ/ገጾች ከህዝብ ይደበቃሉ)። **🆘 የይለፍ ቃል ረሳሁ**፦ ስልኩ በ Telegram ስለሚረጋገጥ በቦቱ አዲስ የይለፍ ቃል ይፈጠራል። `/login` ሌላ አካውንት ለመግባት።
- **ማስታወሻ፦** የጋሪ እና የንግግር ሁኔታ በ Postgres ይቀመጣል። `server/templates.generated.js` ከ `src/lib/templates.js` የተፈጠረ ነው (አብነት ከቀየሩ እንደገና ይፍጠሩ፦ `esbuild src/lib/templates.js --format=cjs --outfile=server/templates.generated.js`)። Webhook አሁን `callback_query` ይቀበላል — ከ deploy በኋላ በራሱ ይዘጋጃል።

## 🛡️ ስሪት 7 — የአድሚን መግቢያ በ 3 ማረጋገጫ
1. **ኢሜይል + የይለፍ ቃል** — `tirunehawoke12@gmail.com` + `ADMIN_PASSWORD`
2. **Telegram፦** አድሚኑ አንድ ጊዜ በቦቱ `/start` → «📱 ስልኬን አጋራ» ሲል ስልክ **0946705941** በ Telegram ይረጋገጣል (ሌላ ስልክ ያለው Telegram አይሠራም፤ የሌላ ሰው ቁጥር ማጋራት አይቻልም)። ከዚያ በኋላ በእያንዳንዱ መግቢያ 6 አሃዝ ኮድ ወደዚያ chat ይላካል። `ADMIN_TELEGRAM_CHAT_ID` ባይሞላም ይሠራል።
3. **ኢሜይል ኮድ፦** 6 አሃዝ ኮድ ወደ `ADMIN_EMAIL` ይላካል — `RESEND_API_KEY` ወይም `BREVO_API_KEY` ወይም `SMTP_*` መዘጋጀት አለበት (`.env.example` ይመልከቱ)።
ኮዶች 10 ደቂቃ ይቆያሉ፣ 5 ሙከራ ብቻ፣ አንዴ ጥቅም ላይ ከዋሉ ይሰረዛሉ። **ማስታወሻ፦** ኢሜይል አቅራቢ ካልተዘጋጀ በጊዜያዊነት Telegram ብቻ ይጠየቃል (Logs ውስጥ ማስጠንቀቂያ ይታያል) — መጀመሪያ እንዳይቆለፉ። የአድሚን ኢሜይል እንደ ተራ ተጠቃሚ መመዝገብ አይቻልም።

## ማስታወሻዎች
- የድሮ አካውንቶች (የድሮው ገጽ የፈጠራቸው) በተመሳሳይ ኢሜይል/ስልክ እና የይለፍ ቃል ይገባሉ፤ Telegram ካልተገናኙ አንድ ጊዜ «ስልኬን አጋራ» ያደርጋሉ።
- የድሮው አጠቃላይ የዳታቤዝ API (`/api/db`፣ `/api/session`፣ `/api/account`) ተዘግቷል (ያለ OTP አካውንት መፍጠር እንዳይቻል)።
- Google Search Console ማረጋገጫ ፋይል (`public/google423971619482a954.html`) ተካትቷል።


## v9 — አዲስ ዲዛይን፣ ገጾች በገበያ ላይ፣ «በዝርዝር እይ / አሳንስ»
- **የጋራ ክፍል** `src/components/Expand.jsx` (`ExpandCard`, `ExpandGroup`, `MoreText`, `Facts`, `Gallery`) — ማንኛውም መዝገብ «👁 በዝርዝር እይ» ↔ «🙈 አሳንስ» አለው፤ በእያንዳንዱ ዝርዝር ላይ «ሁሉንም በዝርዝር እይ / አሳንስ» ቁልፍ አለ።
- ካርዶች (`src/components/CardsX.jsx`)፦ ዕቃ፣ ሱቅ፣ ሥራ፣ ሙያተኛ፣ አሰሪ፣ በተጠቃሚ የተሠራ ገጽ።
- **የተመዘገቡ ገጾች በገበያ ላይ**፦ `/market` ታች፣ መነሻ ገጽ፣ እና `/sites`፤ በሁሉም ክፍሎች ላይ የገበያ ትር (`MarketTabs`፦ ዕቃዎች · ሱቆች · ገጾች · ሙያተኞች · ሥራ)።
- «በዝርዝር እይ» ያገኙ ገጾች፦ መነሻ፣ ገበያ፣ ሱቆች፣ ሥራ/ሙያተኞች፣ ገጾች፣ ትዕዛዞቼ፣ ማመልከቻዎቼ፣ አመልካቾች፣ የእኔ ዕቃዎች/ትዕዛዞች፣ አድሚን ትዕዛዞች።
- ዲዛይን፦ አዲስ መነሻ (የአመኔታ ምልክቶች፣ ምድብ ሰቆች)፣ የዋጋ ባጅ፣ «አዲስ/ጥቂት ቀሩ» ምልክት፣ የሞባይል ፍለጋ፣ ተሰብሳቢ ማጣሪያ፣ እንቅስቃሴ-ቅነሳ ድጋፍ።
- ኤፒአይ፦ `/api/pages` ካርድ አሁን `about`፣ `phone` (ባለቤቱ ካሳየ ብቻ)፣ `topics`፣ `hasForm` ይመልሳል።


## v10 — ስለ እኛ · እገዛ · ግላዊነት · ደንቦች + SEO
- `/about` (አጠቃላይ ሥራ፣ Telegram ቦት @Ethio_Digital_marketing_Bot፣ ደህንነት፣ ግላዊነት፣ FAQ፣ ማን ሠራው)፣ `/help`፣ `/privacy`፣ `/terms` — ይዘት በአንድ ምንጭ `src/lib/aboutContent.js`።
- Google፦ `FAQPage` + `AboutPage` + `Organization` (sameAs: ቦት፣ contactPoint) JSON-LD፣ በተጠቃሚ ገጾች `LocalBusiness/Hotel/Store` JSON-LD፣ ሰፋ ያለ `sitemap.xml`፣ `manifest.webmanifest`፣ canonical/hreflang፣ `robots.txt`።
- **Google Search Console**፦ `public/google423971619482a954.html` አለ። በ meta tag ለማረጋገጥ በ Render `GOOGLE_SITE_VERIFICATION=<ኮድ>` ያስገቡ። ከዚያ Search Console → Sitemaps → `sitemap.xml` ያስገቡ።
- ጽሑፎቹ (ግላዊነት/ደንቦች) አጠቃላይ ማብራሪያ ናቸው፤ የሕግ ባለሙያ እንዲያይዋቸው ይመከራል።


## v11 — የምስል ማከማቻ ከ Postgres ውጭ (Cloudflare R2 / S3)
ምስሎች በ Postgres ውስጥ ሲቀመጡ ሰርቨሩ ሁሉንም በማህደረ ትውስታ ስለሚጭን ጣቢያው ይከብዳል። አሁን ምስሎች ወደ S3-ተስማሚ ማከማቻ መሄድ ይችላሉ (ተጨማሪ npm ጥቅል የለም — `server/imgstore.js`፣ AWS SigV4 በ AWS ይፋዊ ምሳሌዎች ተረጋግጧል)።
1. Cloudflare → R2 → ባልዲ ይፍጠሩ → **Manage R2 API Tokens** → *Object Read & Write* ቁልፍ ይፍጠሩ። ባልዲው ላይ **Public access** (r2.dev) ያብሩ።
2. Render → Environment፦ `S3_ENDPOINT`, `S3_BUCKET`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_PUBLIC_URL` (ቁልፎቹን በ chat አይላኩ)።
3. Deploy → አድሚን → ማርኬት → «🖼️ የምስል ማከማቻ» → «ነባር ምስሎችን አዛውር»። እያንዳንዱ ምስል ተጽፎ እና ተነብቦ ከተረጋገጠ በኋላ ብቻ ከ Postgres ይወገዳል፤ ማዛወር ሲወድቅ ምስሉ በ DB ይቆያል።
- አዲስ ሰቀላ ወደ R2 ይሄዳል፤ R2 ቢወድቅ በ Postgres ይቀመጣል (ምንም ምስል አይጠፋም)። ከ R2 የሚወርዱ ምስሎች በቀጥታ ከ `S3_PUBLIC_URL` (302) ይመጣሉ።
- ከ S3 ጋር ሲሠራ የምስል ከፍተኛ መጠን ከ ~280KB ወደ ~660KB ይጨምራል።
